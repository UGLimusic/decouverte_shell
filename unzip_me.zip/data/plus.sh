read first_num 
read second_num 
result=$(($first_num + $second_num)) 
echo $result 
